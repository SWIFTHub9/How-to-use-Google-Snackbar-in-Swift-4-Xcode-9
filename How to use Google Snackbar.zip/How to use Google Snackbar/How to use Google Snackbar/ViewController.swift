//
//  ViewController.swift
//  How to use Google Snackbar
//
//  Created by Abhishek Verma on 29/03/18.
//  Copyright © 2018 Abhishek Verma. All rights reserved.
//

import UIKit
import MaterialComponents.MaterialSnackbar

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Open_Snackbar(_ sender: Any) {
        let message = MDCSnackbarMessage()
        
        let action = MDCSnackbarMessageAction()
        let actionhandler = {() in
            let actionmessage = MDCSnackbarMessage()
            actionmessage.text = "Button Click Success"
            MDCSnackbarManager.show(actionmessage)
        }
        action.handler = actionhandler
        action.title = "Done"
        message.action = action
        
        message.text = "Welcome Swifthub IOS Tutorials"
        MDCSnackbarManager.show(message)
    }
    
}

